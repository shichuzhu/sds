package main

import (
	"fa18cs425mp/src/lib/stream/shared"
)

type Halver struct {
	// states
	*shared.Collector
}

func (s *Halver) Init() {
	return
}

func (s *Halver) Execute() {
	return
}

func (s *Halver) CheckPoint() {
	return
}
