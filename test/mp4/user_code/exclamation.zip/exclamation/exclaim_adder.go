package main

import (
	"fa18cs425mp/src/lib/stream/shared"
)

type ExclaimAdder struct {
	// states
	*shared.Collector
}

func (s *ExclaimAdder) Init() {
	return
}

func (s *ExclaimAdder) Execute() {
	return
}
